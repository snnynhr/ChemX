ChemistryX - v1.000.036b

Sunny Nahar

Written in Basic and compiled into an APP (1 SPACE) due to number of pics.

Controls: 
up, down arrow keys to scroll.
[0]-[F] to select
[F1] for pull up menu

The program is styled as a database program - list of formulas and notes
  1. Cation List
  2. Polyatomic Ion List
  3. Dissociation Rules
  4. Strong Acids/Bases
  5. Oxidation Reduction
  6. Gas Laws
  7. Enthalpy
  8. Metal Colors
  9. Molecular Geometry
  0. Periodic Trends
  A. Molecular Orbitals
  B. Bonding
  C. Solubility
  D. Chemical Kinetics
  E. Equilibrium
  F. Reactions I-V

Email me at sunnynahar726@gmail.com if you have suggestions to optimize/add new stuff/comments/improvements/corrections.